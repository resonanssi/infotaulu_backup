rm -rf modules
rm config.js
rm main.css
rm custom.css

cp -r ../MagicMirror/modules .
cp ../MagicMirror/config/config.js .
cp ../MagicMirror/css/main.css .
cp ../MagicMirror/css/custom.css .
