# Module: Clock

The `clock` module is one of the default modules of the MagicMirror².
This module displays the current date and time. The information will be updated realtime.

For configuration options, please check the [MagicMirror² documentation](https://docs.magicmirror.builders/modules/clock.html).
