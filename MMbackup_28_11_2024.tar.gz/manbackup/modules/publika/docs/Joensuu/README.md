# Publika > Joensuu

Joensuu public transport schedule times module for MirrorMirror project

![Module](xjxhgvrj.png)

Quick config example:

```js
{
  module: "publika",
  position: "top_left",
  config: {
    feed: "Joensuu",
    stops: [115161]
  }
}
```

Read the full specifications: [README.md](../../README.md#publika)
