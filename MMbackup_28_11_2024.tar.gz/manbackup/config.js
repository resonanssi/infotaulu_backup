/* Config Sample
 *
 * For more information on how you can configure this file
 * see https://docs.magicmirror.builders/configuration/introduction.html
 * and https://docs.magicmirror.builders/modules/configuration.html
 *
 * You can use environment variables using a `config.js.template` file instead of `config.js`
 * which will be converted to `config.js` while starting. For more information
 * see https://docs.magicmirror.builders/configuration/introduction.html#enviromnent-variables
 */
let config = {
	address: "localhost",	// Address to listen on, can be:
							// - "localhost", "127.0.0.1", "::1" to listen on loopback interface
							// - another specific IPv4/6 to listen on a specific interface
							// - "0.0.0.0", "::" to listen on any interface
							// Default, when address config is left out or empty, is "localhost"
	port: 8080,
	basePath: "/",	// The URL path where MagicMirror² is hosted. If you are using a Reverse proxy
									// you must set the sub path here. basePath must end with a /
	ipWhitelist: ["127.0.0.1", "::ffff:127.0.0.1", "::1"],	// Set [] to allow all IP addresses
									// or add a specific IPv4 of 192.168.1.5 :
									// ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.1.5"],
									// or IPv4 range of 192.168.3.0 --> 192.168.3.15 use CIDR format :
									// ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.3.0/28"],

	useHttps: false,			// Support HTTPS or not, default "false" will use HTTP
	httpsPrivateKey: "",	// HTTPS private key path, only require when useHttps is true
	httpsCertificate: "",	// HTTPS Certificate path, only require when useHttps is true

	language: "fi",
	locale: "en-US",
	logLevel: ["INFO", "LOG", "WARN", "ERROR"], // Add "DEBUG" for even more logging
	timeFormat: 24,
	units: "metric",

	modules: [
		{
			module: "clock",
			position: "top_left",
			config: {
				}
		},
		{
			module: "helloworld",
			position: "top_left",
			config: {
				text: "Leffakerho keskiviikkoisin klo 17, Liikuntavuoro torstaisin klo 18"
				}
		},
		{
			module: "calendar",
			header: "Tulevat tapahtumat",
			position: "top_left",
			config: {
				fade: false,
				excludedEvents: ["Jaakko-kullan leffakerho", "Liikuntavuoro"],
				calendars: [
					{
						fetchInterval: 7 * 24 * 60 * 60 * 1000,
						symbol: "wave-square",
						url: "https://calendar.google.com/calendar/ical/webmaster%40resonanssi.org/public/basic.ics"
					},
					{
						fetchInterval: 7 * 24 * 60 * 60 * 1000,
						symbol: "cloud",
						url: "https://calendar.google.com/calendar/ical/synopkalenteri%40gmail.com/public/basic.ics"
					},
					{
						fetchInterval: 7 * 24 * 60 * 60 * 1000,
						symbol: "star",
						url: "https://calendar.google.com/calendar/ical/1r043qtbimidj6ddkpf7c369mo%40group.calendar.google.com/public/basic.ics"
					},
				]
			}
		},
		{
			module: "newsfeed",
			position: "bottom_bar",
			config: {
				feeds: [
					{
						title: "Helsingin Sanomat",
						url: "https://www.hs.fi/rss/teasers/etusivu.xml"
					},	
					{
						title: "Yle Uutiset",
						url: "https://feeds.yle.fi/uutiset/v1/majorHeadlines/YLE_UUTISET.rss"
					}
				],
				showSourceTitle: true,
				showPublishDate: true,
				broadcastNewsFeeds: true,
				broadcastNewsUpdates: true
			}
		},
		{
			module: "MMM-EasyBack",
			position: "fullscreen_below",
			config: {
				bgName: "takaosa.jpg"
				}
		},
		{
			module: "publika",
			position: "top_right",
			config: {
				core: true,
				feed: "HSL",
				digiTransitApiKey: "d1e1ed17ee94476eac414f0cac0df3ab",
				stops: [1240133, 1240134, 1240419],
				theme: "mono",
				stopTimesCount: 4
			}
		},
		{
			module: "publika",
			position: "top_right",
			config: {
				feed: "HSL",
				digiTransitApiKey: "d1e1ed17ee94476eac414f0cac0df3ab",
				stops: [1240103],
				theme: "mono",
				stopTimesCount: 18
			}
		},
		{
			module: "MMM-CountDown",
			position: "top_right",
			config: {
				event: "KJYR-TJ",
				date: "2024-11-16",
				daysLabel: "",
				isAnnual: true

			}
		}
	]
};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") { module.exports = config; }
